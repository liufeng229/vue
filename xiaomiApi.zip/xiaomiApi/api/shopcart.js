module.exports={
    getDate(){
        let data={
            goods:[
                {
                    "shop" :"有品精选",
                    "fee" :"运费已免",
                    "mainInfo" : {
                        "pic" :"img/watch.jpg",
                        "title" : "AMAZFIT 米动手表青春版",
                        "des" :"Lite&nbsp;耀石黑&nbsp;标配",
                        "pic" :"299",
                        "num" :"1"
                    }
                }
            ]
        }
        return data
    }
}